package com.example.dunkslam

import android.app.Activity
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.LocalActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.imageResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.random.Random

enum class EstadoJuego {
    MENU, JUGANDO
}

data class Particula(
    var x: Float,
    var y: Float,
    var vx: Float,
    var vy: Float,
    var vida: Float,
    val color: Color
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AppBaloncesto()
        }
    }
}

@Composable
fun AppBaloncesto() {
    var estado by remember { mutableStateOf(EstadoJuego.MENU) }

    when (estado) {
        EstadoJuego.MENU -> {
            PantallaInicio(
                onJugarClick = { estado = EstadoJuego.JUGANDO }
            )
        }
        EstadoJuego.JUGANDO -> {
            JuegoDunkCorregido()
        }
    }
}

@Composable
fun PantallaInicio(onJugarClick: () -> Unit) {
    val activity = LocalActivity.current

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF1A1A1A), Color(0xFF000000)))),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = "DUNK SLAM",
                color = Color(0xFFE4A660),
                fontSize = 56.sp,
                fontWeight = FontWeight.ExtraBold,
                modifier = Modifier.padding(bottom = 64.dp)
            )

            BotonMenu(texto = "JUGAR", color = Color(0xFFE4A660), onClick = onJugarClick)

            Spacer(modifier = Modifier.height(24.dp))

            BotonMenu(texto = "SALIR", color = Color(0xFFB00020).copy(alpha = 0.8f), onClick = {
                activity?.finish()
            })
        }
    }
}

@Composable
fun BotonMenu(texto: String, color: Color, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .width(220.dp)
            .height(65.dp)
            .background(color, shape = RoundedCornerShape(12.dp))
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = texto,
            color = Color.White,
            fontSize = 26.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun JuegoDunkCorregido() {
    val haptic = LocalHapticFeedback.current

    // Estado del balón
    var bolaX by remember { mutableStateOf(500f) }
    var bolaY by remember { mutableStateOf(1400f) }
    var velocidadY by remember { mutableStateOf(0f) }
    var velocidadX by remember { mutableStateOf(0f) }
    var escala by remember { mutableStateOf(1.0f) }
    var rotacion by remember { mutableStateOf(0f) }

    // Racha y puntuación
    var puntos by remember { mutableStateOf(0) }
    var puntaje by remember { mutableStateOf(0) }
    var fallos by remember { mutableStateOf(0) }
    var velocidadAro by remember { mutableStateOf(8f) }
    val velocidadBase = 8f
    var bolaEnVuelo by remember { mutableStateOf(false) }
    var estaPresionando by remember { mutableStateOf(false) }

    // Temática
    val esFutbol = puntaje >= 10

    // Efectos Visuales
    val estelaPosiciones = remember { mutableStateListOf<Offset>() }
    val particulas = remember { mutableStateListOf<Particula>() }
    var tiempoFuego by remember { mutableStateOf(0f) }

    var mostrarTutorial by remember { mutableStateOf(false) }

    val lineaSueloLejos = 900f
    var aroX by remember { mutableStateOf(300f) }
    val aroY = 500f
    var direccionAro by remember { mutableStateOf(1f) }

    val imagenPelota = ImageBitmap.imageResource(id = R.drawable.pelota_baloncesto)
    val imagenCanasta = ImageBitmap.imageResource(id = R.drawable.basket)

    val hitboxAncho = 100f
    val hitboxAlto = 35f
    val offsetXHitbox = 80f
    val offsetYHitbox = 185f

    LaunchedEffect(estaPresionando, bolaEnVuelo) {
        if (!estaPresionando && !bolaEnVuelo) {
            delay(10000)
            mostrarTutorial = true
        } else {
            mostrarTutorial = false
        }
    }

    LaunchedEffect(Unit) {
        while (true) {
            delay(16)
            tiempoFuego += 0.1f

            val iterator = particulas.iterator()
            while (iterator.hasNext()) {
                val p = iterator.next()
                p.x += p.vx
                p.y += p.vy
                p.vy += 0.2f
                p.vida -= 0.02f
                if (p.vida <= 0) iterator.remove()
            }

            if (bolaEnVuelo && !estaPresionando) {
                velocidadY += 1.8f
                bolaY += velocidadY
                bolaX += velocidadX
                rotacion += velocidadX * 2f

                if (puntos >= 3) {
                    estelaPosiciones.add(0, Offset(bolaX, bolaY))
                    if (estelaPosiciones.size > 10) estelaPosiciones.removeAt(10)
                } else {
                    estelaPosiciones.clear()
                }

                if (velocidadY < 0) {
                    escala = Math.max(0.4f, escala - 0.025f)
                }

                val hitboxRect = Rect(
                    left = aroX + offsetXHitbox,
                    top = aroY + offsetYHitbox,
                    right = aroX + offsetXHitbox + hitboxAncho,
                    bottom = aroY + offsetYHitbox + hitboxAlto
                )

                if (escala < 0.65f && velocidadY > 0) {
                    if (hitboxRect.contains(Offset(bolaX, bolaY))) {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        puntos++
                        puntaje++
                        
                        repeat(15) {
                            particulas.add(
                                Particula(
                                    aroX + 130f, aroY + 200f,
                                    Random.nextFloat() * 10 - 5,
                                    Random.nextFloat() * -10 - 2,
                                    1.0f,
                                    if (puntos >= 3) Color.Yellow else Color(if (esFutbol) 0xFF4CAF50 else 0xFFE4A660)
                                )
                            )
                        }

                        // Bajamos un poco la velocidad si es futbol
                        if (puntaje == 10) {
                            velocidadAro = 6f
                        } else {
                            velocidadAro += 0.5f
                        }

                        bolaEnVuelo = false
                        bolaY = 1400f
                        bolaX = 500f
                        escala = 1.0f
                        velocidadY = 0f
                        velocidadX = 0f
                        rotacion = 0f
                        estelaPosiciones.clear()
                    }
                }

                if (bolaEnVuelo && escala < 0.75f && bolaY > lineaSueloLejos) {
                    puntos = 0
                    fallos++
                    velocidadAro = if (esFutbol) 6f else velocidadBase
                    bolaEnVuelo = false
                    bolaY = 1400f
                    bolaX = 500f
                    escala = 1.0f
                    velocidadY = 0f
                    velocidadX = 0f
                    rotacion = 0f
                    estelaPosiciones.clear()
                }

                if (bolaY > 2200f) {
                    bolaEnVuelo = false
                    bolaY = 1400f
                    bolaX = 500f
                    escala = 1.0f
                    rotacion = 0f
                    estelaPosiciones.clear()
                }
            } else {
                estelaPosiciones.clear()
            }

            aroX += velocidadAro * direccionAro
            if (aroX > 800f || aroX < 100f) direccionAro *= -1
        }
    }

    Canvas(modifier = Modifier.fillMaxSize().pointerInput(Unit) {
        detectDragGestures(
            onDragStart = { if (!bolaEnVuelo) estaPresionando = true },
            onDragEnd = {
                if (estaPresionando) {
                    estaPresionando = false
                    bolaEnVuelo = true
                    velocidadY = -48f
                    velocidadX = (bolaX - 500f) / 8f
                }
            },
            onDrag = { _, dragAmount ->
                if (estaPresionando) {
                    bolaX += dragAmount.x
                    bolaY += dragAmount.y
                }
            }
        )
    }) {

        // --- FONDO TEMÁTICO ---
        if (!esFutbol) {
            // Fondo Baloncesto
            drawRect(color = Color(0xFFa18262), size = Size(size.width, lineaSueloLejos))
            drawRect(color = Color(0xFFE4A660), topLeft = Offset(0f, lineaSueloLejos), size = Size(size.width, size.height - lineaSueloLejos))
            for (i in 0..15) {
                val yPos = lineaSueloLejos + (i * (size.height - lineaSueloLejos) / 15)
                drawLine(color = Color.Black.copy(alpha = 0.05f), start = Offset(0f, yPos), end = Offset(size.width, yPos), strokeWidth = 2f)
            }
            val centroX = size.width / 2
            drawRect(color = Color(0xFFC08552).copy(alpha = 0.5f), topLeft = Offset(centroX - 250f, lineaSueloLejos), size = Size(500f, size.height - lineaSueloLejos))
            drawLine(Color.White.copy(alpha = 0.6f), Offset(centroX - 250f, lineaSueloLejos), Offset(centroX - 250f, size.height), strokeWidth = 8f)
            drawLine(Color.White.copy(alpha = 0.6f), Offset(centroX + 250f, lineaSueloLejos), Offset(centroX + 250f, size.height), strokeWidth = 8f)
            drawLine(Color.White.copy(alpha = 0.6f), Offset(0f, lineaSueloLejos), Offset(size.width, lineaSueloLejos), strokeWidth = 8f)
            drawArc(color = Color.White.copy(alpha = 0.6f), startAngle = 180f, sweepAngle = 180f, useCenter = false, topLeft = Offset(centroX - 250f, lineaSueloLejos + 150f), size = Size(500f, 300f), style = Stroke(width = 8f))
        } else {
            // Fondo Fútbol (Césped)
            drawRect(color = Color(0xFF1B5E20), size = Size(size.width, lineaSueloLejos))
            drawRect(color = Color(0xFF2E7D32), topLeft = Offset(0f, lineaSueloLejos), size = Size(size.width, size.height - lineaSueloLejos))
            
            // Patrón de corte de césped
            for (i in 0..10) {
                val yPos = lineaSueloLejos + (i * (size.height - lineaSueloLejos) / 10)
                if (i % 2 == 0) {
                    drawRect(color = Color.White.copy(alpha = 0.05f), topLeft = Offset(0f, yPos), size = Size(size.width, (size.height - lineaSueloLejos) / 10))
                }
            }

            val centroX = size.width / 2
            // Área grande
            drawRect(color = Color.White.copy(alpha = 0.4f), topLeft = Offset(centroX - 350f, lineaSueloLejos), size = Size(700f, 400f), style = Stroke(width = 8f))
            // Punto de penalti
            drawCircle(color = Color.White.copy(alpha = 0.4f), radius = 10f, center = Offset(centroX, lineaSueloLejos + 300f))
        }

        // --- ESTELA ---
        if (estelaPosiciones.isNotEmpty()) {
            estelaPosiciones.forEachIndexed { index, offset ->
                val alpha = (10 - index) / 15f
                drawCircle(
                    color = (if (esFutbol) Color.Cyan else Color.Yellow).copy(alpha = alpha),
                    radius = 100f * escala * alpha,
                    center = offset
                )
            }
        }

        // --- CANASTA / PORTERÍA ---
        withTransform({ translate(left = aroX, top = aroY) }) {
            if (!esFutbol) {
                drawImage(image = imagenCanasta, dstSize = IntSize(260, 290))
            } else {
                // Dibujar una portería simple con líneas si no hay imagen de portería
                drawRect(Color.White, topLeft = Offset(20f, 0f), size = Size(220f, 10f)) // larguero
                drawRect(Color.White, topLeft = Offset(20f, 0f), size = Size(10f, 250f)) // poste izq
                drawRect(Color.White, topLeft = Offset(230f, 0f), size = Size(10f, 250f)) // poste der
                // Red
                for(i in 0..5) {
                    drawLine(Color.White.copy(alpha = 0.3f), Offset(20f + i*40f, 0f), Offset(20f + i*40f, 250f), 2f)
                    drawLine(Color.White.copy(alpha = 0.3f), Offset(20f, i*50f), Offset(230f, i*50f), 2f)
                }
            }
        }

        // --- EXPLOSIÓN ---
        particulas.forEach { p ->
            drawCircle(color = p.color.copy(alpha = p.vida), radius = 8f, center = Offset(p.x, p.y))
        }

        // --- PELOTA ---
        val tamPelota = 270f
        withTransform({
            scale(escala, escala, pivot = Offset(bolaX, bolaY))
            rotate(rotacion, pivot = Offset(bolaX, bolaY))
            translate(bolaX - tamPelota/2, bolaY - tamPelota/2)
        }) {
            if (!esFutbol) {
                drawImage(image = imagenPelota, dstSize = IntSize(tamPelota.toInt(), tamPelota.toInt()), alpha = if (estaPresionando) 0.7f else 1f)
            } else {
                // Dibujar balón de fútbol (Blanco con hexágonos)
                drawCircle(Color.White, radius = tamPelota / 2)
                drawCircle(Color.Black, radius = tamPelota / 2, style = Stroke(4f))
                // Dibujar algunos "parches"
                drawCircle(Color.Black, radius = 30f, center = Offset(tamPelota/2, tamPelota/2))
                drawCircle(Color.Black, radius = 25f, center = Offset(tamPelota/2 - 60f, tamPelota/2 - 40f))
                drawCircle(Color.Black, radius = 25f, center = Offset(tamPelota/2 + 60f, tamPelota/2 - 40f))
                drawCircle(Color.Black, radius = 25f, center = Offset(tamPelota/2 - 50f, tamPelota/2 + 70f))
                drawCircle(Color.Black, radius = 25f, center = Offset(tamPelota/2 + 50f, tamPelota/2 + 70f))
            }
        }

        // --- UI ---
        drawContext.canvas.nativeCanvas.apply {
            val paint = android.graphics.Paint().apply {
                isFakeBoldText = true
                textAlign = android.graphics.Paint.Align.LEFT
            }

            paint.textSize = 70f
            if (puntos >= 3) {
                paint.color = if (esFutbol) android.graphics.Color.CYAN else android.graphics.Color.YELLOW
                paint.setShadowLayer(20f, 0f, 0f, android.graphics.Color.RED)
                drawText("RACHA: $puntos 🔥", 50f, 150f, paint)
            } else {
                paint.color = android.graphics.Color.WHITE
                paint.clearShadowLayer()
                drawText("RACHA: $puntos", 50f, 150f, paint)
            }

            paint.clearShadowLayer()
            paint.textSize = 45f
            paint.color = android.graphics.Color.WHITE
            drawText("ANOTADOS: $puntaje", 50f, 220f, paint)
            
            paint.color = android.graphics.Color.parseColor("#FFBB86FC")
            drawText("FALLOS: $fallos", 50f, 280f, paint)

            if (esFutbol) {
                paint.color = android.graphics.Color.GREEN
                paint.textSize = 60f
                paint.textAlign = android.graphics.Paint.Align.CENTER
                drawText("¡MODO FÚTBOL!", size.width/2, 80f, paint)
            }

            if (mostrarTutorial) {
                paint.textAlign = android.graphics.Paint.Align.CENTER
                paint.color = android.graphics.Color.WHITE
                paint.alpha = 180
                paint.textSize = 50f
                drawText("¡DESLIZA PARA LANZAR!", size.width/2, bolaY - 200f, paint)
            }
        }
    }
}
